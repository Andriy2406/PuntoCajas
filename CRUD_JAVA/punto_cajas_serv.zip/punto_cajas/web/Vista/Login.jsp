<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Punto Cajas | Iniciar sesión</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="${pageContext.request.contextPath}/Vista/CSS/styles.css" rel="stylesheet">
</head>
<body>

    <nav class="navbar navbar-punto py-3">
        <div class="container">
            <a class="navbar-brand" href="${pageContext.request.contextPath}/">
                <svg class="logo-caja" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
                    <path d="M3 7l9-4 9 4-9 4-9-4z"/>
                    <path d="M3 7v10l9 4 9-4V7"/>
                    <path d="M12 11v10"/>
                </svg>
                Punto Cajas
            </a>
        </div>
    </nav>

    <main class="d-flex align-items-center">
        <div class="container">
            <div class="contenedor-formulario">
                <h1>Iniciar sesión</h1>
                <p class="subtitulo">Ingresa con tu correo y contraseña registrados</p>

                <c:if test="${not empty requestScope.error}">
                    <div class="alert alert-danger text-center" role="alert">
                        ${requestScope.error}
                    </div>
                </c:if>

                <form action="${pageContext.request.contextPath}/LoginServlet" method="POST">
                    <div class="mb-3">
                        <label for="correo">Correo:</label>
                        <input type="email" name="correo" id="correo" class="form-control" placeholder="ejemplo@correo.com" required>
                    </div>

                    <div class="mb-3">
                        <label for="clave">Contraseña:</label>
                        <input type="password" name="clave" id="clave" class="form-control" placeholder="Ingresa tu contraseña" required>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="recordar">
                            <label class="form-check-label" for="recordar">Recordarme</label>
                        </div>
                        <a href="${pageContext.request.contextPath}/Vista/RecuperarClave.jsp" class="small">¿Olvidaste tu contraseña?</a>
                    </div>

                    <button type="submit" class="btn btn-punto-primario w-100">Iniciar sesión</button>
                </form>

                <p class="text-center mt-4 mb-0">
                    ¿Aún no tienes cuenta?
                    <a href="${pageContext.request.contextPath}/Vista/Registro.jsp">Regístrate aquí</a>
                </p>
            </div>
        </div>
    </main>

    <footer class="footer-punto">
        <div class="container text-center">
            <span>&copy; 2026 Punto Cajas. Todos los derechos reservados.</span>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>