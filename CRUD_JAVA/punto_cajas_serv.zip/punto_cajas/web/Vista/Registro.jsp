<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Punto Cajas | Crear cuenta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="${pageContext.request.contextPath}/Vista/CSS/registro.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-punto py-3">
        <div class="container">
            <a class="navbar-brand" href="${pageContext.request.contextPath}/InicioServlet">
                <svg class="logo-caja" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
                    <path d="M3 7l9-4 9 4-9 4-9-4z"/>
                    <path d="M3 7v10l9 4 9-4V7"/>
                    <path d="M12 11v10"/>
                </svg>
                Punto Cajas
            </a>
        </div>
    </nav>
    <main>
        <div class="container">
            <div class="contenedor-formulario">
                <div class="text-center">
                    <h1>Crear cuenta</h1>
                    <p class="subtitulo">Regístrate para cotizar y comprar tus cajas.</p>
                </div>
                <c:if test="${not empty requestScope.mensaje}">
                    <div class="alert alert-success text-center" role="alert">
                        ${requestScope.mensaje}
                    </div>
                </c:if>
                <c:if test="${not empty requestScope.error}">
                    <div class="alert alert-danger text-center" role="alert">
                        ${requestScope.error}
                    </div>
                </c:if>
                <form action="${pageContext.request.contextPath}/RegistroServlet" method="POST">
                    <h2>Datos personales</h2>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="nombre" class="form-label">Nombre</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Tu nombre" minlength="2" maxlength="50" autocomplete="given-name" required>
                        </div>
                        <div class="col-md-6">
                            <label for="apellido" class="form-label">Apellido</label>
                            <input type="text" class="form-control" id="apellido" name="apellido" placeholder="Tu apellido" minlength="2" maxlength="50" autocomplete="family-name" required>
                        </div>
                    </div>
                    <h2>Documento de identidad</h2>
                    <div class="row g-3">
                        <div class="col-md-5">
                            <label for="tipoDocumento" class="form-label">Tipo de documento</label>
                            <select class="form-select" id="tipoDocumento" name="id_documento" required>
                                <option value="" selected disabled>Selecciona...</option>
                                <option value="1">Cédula de Ciudadanía</option>
                                <option value="2">Tarjeta de Identidad</option>
                                <option value="3">Pasaporte</option>
                                <option value="4">Cédula de Extranjería</option>
                                <option value="5">Registro Civil</option>
                                <option value="6">NIT</option>
                                <option value="7">Documento Nacional de Identidad</option>
                                <option value="8">Carné de Extranjería</option>
                                <option value="9">PEP</option>
                                <option value="10">Permiso por Protección Temporal</option>
                            </select>
                        </div>
                        <div class="col-md-7">
                            <label for="identificacion_usuario" class="form-label">Número de documento</label>
                            <input type="text" class="form-control" id="identificacion_usuario" name="identificacion_usuario" placeholder="Ej: 1020304050" minlength="5" maxlength="20" autocomplete="off" required>
                        </div>
                    </div>
                    <h2>Información de contacto</h2>
                    <div class="mb-3">
                        <label for="correo" class="form-label">Correo electrónico</label>
                        <input type="email" class="form-control" id="correo" name="correo" placeholder="nombre@correo.com" maxlength="100" autocomplete="email" required>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="telefono" class="form-label">Teléfono</label>
                            <input type="tel" class="form-control" id="telefono" name="telefono" placeholder="Ej: 3001234567" pattern="[0-9]{7,15}" maxlength="15" autocomplete="tel">
                            <div class="form-text">Ingresa entre 7 y 15 números.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="fecha_de_nacimiento" class="form-label">Fecha de nacimiento</label>
                            <input type="date" class="form-control" id="fecha_de_nacimiento" name="fecha_de_nacimiento" autocomplete="bday">
                        </div>
                    </div>
                    <div class="mb-3 mt-3">
                        <label for="direccion" class="form-label">Dirección</label>
                        <input type="text" class="form-control" id="direccion" name="direccion" placeholder="Ej: Calle 10 # 20-30" maxlength="150" autocomplete="street-address">
                    </div>
                    <h2>Seguridad</h2>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="clave" class="form-label">Contraseña</label>
                            <input type="password" class="form-control" id="clave" name="clave" placeholder="Mínimo 6 caracteres" minlength="6" maxlength="100" autocomplete="new-password" required>
                        </div>
                        <div class="col-md-6">
                            <label for="confirmarClave" class="form-label">Confirmar contraseña</label>
                            <input type="password" class="form-control" id="confirmarClave" name="confirmarClave" placeholder="Repite tu contraseña" minlength="6" maxlength="100" autocomplete="new-password" required>
                        </div>
                    </div>
                    <div class="form-check mt-4 mb-4">
                        <input class="form-check-input" type="checkbox" id="autorizacionDatos" name="autorizacionDatos" value="true" required>
                        <label class="form-check-label" for="autorizacionDatos">
                            Autorizo el tratamiento de mis datos personales conforme a la política de privacidad.
                        </label>
                    </div>
                    <button type="submit" class="btn btn-punto-primario w-100">Crear cuenta</button>
                </form>
                <p class="text-center mt-4 mb-0">
                    ¿Ya tienes cuenta?
                    <a href="${pageContext.request.contextPath}/Vista/Login.jsp">Inicia sesión aquí</a>
                </p>
            </div>
        </div>
    </main>
    <footer class="footer-punto">
        <div class="container text-center">
            <span>&copy; 2026 Punto Cajas. Todos los derechos reservados.</span>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>