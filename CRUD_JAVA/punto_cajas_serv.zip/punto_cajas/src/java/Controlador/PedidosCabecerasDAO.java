package Controlador;
import Modelo.PedidosCabeceras;
import java.sql.*;
import java.time.LocalDate;

public class PedidosCabecerasDAO {

    private Conexion conect = new Conexion();

    public PedidosCabeceras consultarPedido(int idPedido) {
        PedidosCabeceras miPedido = null;
        Connection conn = conect.conn();

        try {
            String querySql = "SELECT id_pedido, fecha, direccion_envio, total, "
                    + "estado_pedido, id_cotizacion FROM pedidos_cabeceras WHERE id_pedido = ?";

            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, idPedido);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                miPedido = new PedidosCabeceras();
                miPedido.setIdPedido(rs.getInt("id_pedido"));
                
                Date fechaSql = rs.getDate("fecha");
                if (fechaSql != null) {
                    miPedido.setFecha(fechaSql.toLocalDate());
                }
                
                miPedido.setDireccionEnvio(rs.getString("direccion_envio"));
                miPedido.setTotal(rs.getFloat("total"));
                miPedido.setEstadoPedido(rs.getString("estado_pedido"));
                miPedido.setIdCotizacion(rs.getInt("id_cotizacion"));
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar el Pedido: " + e.getMessage());
        }
        return miPedido;
    }

    public boolean insertarPedido(PedidosCabeceras miPedido) {
        boolean insertar = false;
        Connection conn = conect.conn();

        try {
            String querySql = "INSERT INTO pedidos_cabeceras (fecha, direccion_envio, total, "
                    + "estado_pedido, id_cotizacion) VALUES (?,?,?,?,?)";

            PreparedStatement ps = conn.prepareStatement(querySql);

            if (miPedido.getFecha() != null) {
                ps.setDate(1, java.sql.Date.valueOf(miPedido.getFecha()));
            } else {
                ps.setNull(1, java.sql.Types.DATE);
            }

            ps.setString(2, miPedido.getDireccionEnvio());
            ps.setFloat(3, miPedido.getTotal());
            ps.setString(4, miPedido.getEstadoPedido());
            ps.setInt(5, miPedido.getIdCotizacion());

            ps.executeUpdate();
            insertar = true;
            System.out.println("Pedido registrado exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al insertar el Pedido: " + e.getMessage());
        }
        return insertar;
    }

    public boolean actualizarPedido(PedidosCabeceras miPedido) {
        boolean actualizar = false;
        Connection conn = conect.conn();

        try {
            String querySql = "UPDATE pedidos_cabeceras SET fecha = ?, direccion_envio = ?, "
                    + "total = ?, estado_pedido = ? WHERE id_pedido = ?";

            PreparedStatement ps = conn.prepareStatement(querySql);

            if (miPedido.getFecha() != null) {
                ps.setDate(1, java.sql.Date.valueOf(miPedido.getFecha()));
            } else {
                ps.setNull(1, java.sql.Types.DATE);
            }

            ps.setString(2, miPedido.getDireccionEnvio());
            ps.setFloat(3, miPedido.getTotal());
            ps.setString(4, miPedido.getEstadoPedido());
            ps.setInt(5, miPedido.getIdPedido());

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas > 0) {
                actualizar = true;
                System.out.println("Pedido actualizado correctamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar el Pedido: " + e.getMessage());
        }
        return actualizar;
    }

    public boolean eliminarPedido(int idPedido) {
        boolean eliminar = false;
        Connection conn = conect.conn();

        try {
            String querySql = "DELETE FROM pedidos_cabeceras WHERE id_pedido = ?";
            PreparedStatement ps = conn.prepareStatement(querySql);

            ps.setInt(1, idPedido);

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas > 0) {
                eliminar = true;
            } else {
                System.out.println("No se encontró el ID del Pedido.");
            }
        } catch (SQLException e) {
            System.out.println("No se pudo eliminar el Pedido: " + e.getMessage());
        }
        return eliminar;
    }
}