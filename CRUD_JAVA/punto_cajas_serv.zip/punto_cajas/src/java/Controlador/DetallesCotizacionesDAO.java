package Controlador;
import Modelo.DetallesCotizaciones;
import java.sql.*;

public class DetallesCotizacionesDAO {

    private Conexion conect = new Conexion();

    public DetallesCotizaciones consultarDetalleCotizacion(int idDetalle) {
        DetallesCotizaciones miDetalle = null;
        Connection conn = conect.conn();

        try {
            String querySql = "SELECT id_detalle, cantidad, alto, largo, ancho, color, acabado, "
                    + "descripcion_uso_caja, id_cotizacion FROM detalles_cotizaciones WHERE id_detalle = ?";

            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, idDetalle);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                miDetalle = new DetallesCotizaciones();
                miDetalle.setIdDetalle(rs.getInt("id_detalle"));
                miDetalle.setCantidad(rs.getInt("cantidad"));
                miDetalle.setAlto(rs.getFloat("alto"));
                miDetalle.setLargo(rs.getFloat("largo"));
                miDetalle.setAncho(rs.getFloat("ancho"));
                miDetalle.setColor(rs.getString("color"));
                miDetalle.setAcabado(rs.getString("acabado"));
                miDetalle.setDescripcionUsoCaja(rs.getString("descripcion_uso_caja"));
                miDetalle.setIdCotizacion(rs.getInt("id_cotizacion"));
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar el Detalle de Cotización: " + e.getMessage());
        }
        return miDetalle;
    }

    public boolean insertarDetalleCotizacion(DetallesCotizaciones miDetalle) {
        boolean insertar = false;
        Connection conn = conect.conn();

        try {
            String querySql = "INSERT INTO detalles_cotizaciones (cantidad, alto, largo, ancho, color, "
                    + "acabado, descripcion_uso_caja, id_cotizacion) VALUES (?,?,?,?,?,?,?,?)";

            PreparedStatement ps = conn.prepareStatement(querySql);

            ps.setInt(1, miDetalle.getCantidad());
            ps.setFloat(2, miDetalle.getAlto());
            ps.setFloat(3, miDetalle.getLargo());
            ps.setFloat(4, miDetalle.getAncho());
            ps.setString(5, miDetalle.getColor());
            ps.setString(6, miDetalle.getAcabado());
            ps.setString(7, miDetalle.getDescripcionUsoCaja());
            ps.setInt(8, miDetalle.getIdCotizacion());

            ps.executeUpdate();
            insertar = true;
            System.out.println("Detalle de cotización registrado exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al insertar el Detalle de Cotización: " + e.getMessage());
        }
        return insertar;
    }

    public boolean actualizarDetalleCotizacion(DetallesCotizaciones miDetalle) {
        boolean actualizar = false;
        Connection conn = conect.conn();

        try {
            String querySql = "UPDATE detalles_cotizaciones SET cantidad = ?, alto = ?, largo = ?, ancho = ?, "
                    + "color = ?, acabado = ?, descripcion_uso_caja = ? WHERE id_detalle = ?";

            PreparedStatement ps = conn.prepareStatement(querySql);

            ps.setInt(1, miDetalle.getCantidad());
            ps.setFloat(2, miDetalle.getAlto());
            ps.setFloat(3, miDetalle.getLargo());
            ps.setFloat(4, miDetalle.getAncho());
            ps.setString(5, miDetalle.getColor());
            ps.setString(6, miDetalle.getAcabado());
            ps.setString(7, miDetalle.getDescripcionUsoCaja());
            ps.setInt(8, miDetalle.getIdDetalle());

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas > 0) {
                actualizar = true;
                System.out.println("Detalle de cotización actualizado correctamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar el Detalle de Cotización: " + e.getMessage());
        }
        return actualizar;
    }

    public boolean eliminarDetalleCotizacion(int idDetalle) {
        boolean eliminar = false;
        Connection conn = conect.conn();

        try {
            String querySql = "DELETE FROM detalles_cotizaciones WHERE id_detalle = ?";
            PreparedStatement ps = conn.prepareStatement(querySql);

            ps.setInt(1, idDetalle);

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas > 0) {
                eliminar = true;
            } else {
                System.out.println("No se encontró el ID del Detalle de Cotización.");
            }
        } catch (SQLException e) {
            System.out.println("No se pudo eliminar el Detalle de Cotización: " + e.getMessage());
        }
        return eliminar;
    }
}