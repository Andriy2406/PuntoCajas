package Controlador;
import Modelo.Catalogos;
import java.sql.*;


public class CatalogosDAO {
    
    private Conexion conect = new Conexion();
    
    public Catalogos consultarCatalogo(int id_catalogo){
    
    Catalogos miCatalogo = null;
    
    Connection conn = conect.conn();
    
        try {
            String querySql = "SELECT id_catalogo, stock_actual, url FROM catalogos WHERE id_catalogo = ?";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setInt(1, id_catalogo);
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                
                miCatalogo = new Catalogos();
                miCatalogo.setIdCatalogo(rs.getInt("id_catalogo"));
                miCatalogo.setStockActual(rs.getString("stock_actual"));
                miCatalogo.setUrl(rs.getString("url"));
                
            }
        } catch (SQLException e) {
            
            System.out.println(e.getMessage());
        }
        return miCatalogo;
    }
    
    public boolean insertarCatalogo(Catalogos miCatalogo){
    
        boolean insertar = false;
        
        Connection conn = conect.conn();
        
        try {
            String querySql = "INSERT INTO catalogos (stock_actual, url) VALUES (?,?)";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setString(1, miCatalogo.getStockActual());
            ps.setString(2, miCatalogo.getUrl());
            
            ps.executeUpdate();
            insertar = true;
            System.out.println("Catalogo registrado exitosamente");
        } catch (SQLException e) {
            System.out.println("Error al insertar Catalogo: " + e.getMessage());
            
        }
        return insertar;
    }
    
    public boolean actualizarCatalogo(Catalogos miCatalogo){
        
        boolean actualizar = false;
    
        Connection conn = conect.conn();
        
        try {
            String querySql = "UPDATE catalogos SET stock_actual = ?, url = ? WHERE id_catalogo = ?";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setString(1, miCatalogo.getStockActual());
            ps.setString(2, miCatalogo.getUrl());
            ps.setInt(3, miCatalogo.getIdCatalogo());
            
            int filasAfectadas = ps.executeUpdate();
            
            if (filasAfectadas > 0 ) {
                
                actualizar = true;
                System.out.println("Catalogo actualizado correctamente");
            }
            
        } catch (SQLException e) {
            System.out.println("Error al actualizar Catalogo: " + e.getMessage());
        }
        return actualizar;
    }
    
    public boolean inactivarCatalogo(int id){
    
        boolean inactivar = false; 
        String querySql = "UPDATE catalogos SET estado = FALSE WHERE id_catalogo = ?";
        
        Connection conn = conect.conn();
        
        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, id);
            if (ps.executeUpdate() > 0) {
                inactivar = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al inactivar el Catalogo");
        }
        return inactivar;
    }
    
    public boolean activarCatalogo(int id){
    
        boolean activar = false; 
        String querySql = "UPDATE catalogos SET estado = TRUE WHERE id_catalogo = ?";
        
        Connection conn = conect.conn();
        
        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, id);
            if (ps.executeUpdate() > 0) {
                activar = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al activar el Catalogo");
        }
        return activar;
    }
    
    public boolean eliminarCatalogo(int id){
        
        boolean eliminar = false; 
        
        Connection conn = conect.conn();
        
        try {
            String querySql = "DELETE FROM catalogos WHERE id_catalogo = ?";
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setInt(1, id);
            
            int filasAfectadas = ps.executeUpdate();
            
            if (filasAfectadas > 0) {
                eliminar = true; 
                
            }else{
                System.out.println("No se encontro el ID del Catalogo");
            }
        } catch (SQLException e) {
            System.out.println("No se pudo eliminar el Catalogo: " + e.getMessage());
        }
        return eliminar;
    }
    
}
