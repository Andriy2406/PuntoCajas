package Controlador;

import Modelo.FacturasCabeceras;
import java.sql.*;

public class FacturasCabecerasDAO {

    private Conexion conect = new Conexion();

    public FacturasCabeceras consultarFactura(int idFactura) {
        FacturasCabeceras miFactura = null;
        Connection conn = conect.conn();

        try {
            String querySql = "SELECT id_factura, numero_factura, total, id_pedido, id_cotizacion "
                    + "FROM facturas_cabeceras WHERE id_factura = ?";

            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, idFactura);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                miFactura = new FacturasCabeceras();
                miFactura.setIdFactura(rs.getInt("id_factura"));
                miFactura.setNumeroFactura(rs.getInt("numero_factura"));
                miFactura.setTotal(rs.getFloat("total"));
                miFactura.setIdPedido(rs.getInt("id_pedido"));
                miFactura.setIdCotizacion(rs.getInt("id_cotizacion"));
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar la Factura: " + e.getMessage());
        }
        return miFactura;
    }

    public boolean insertarFactura(FacturasCabeceras miFactura) {
        boolean insertar = false;
        Connection conn = conect.conn();

        try {
            String querySql = "INSERT INTO facturas_cabeceras (numero_factura, total, id_pedido, id_cotizacion) "
                    + "VALUES (?,?,?,?)";

            PreparedStatement ps = conn.prepareStatement(querySql);

            ps.setInt(1, miFactura.getNumeroFactura());
            ps.setFloat(2, miFactura.getTotal());
            ps.setInt(3, miFactura.getIdPedido());
            ps.setInt(4, miFactura.getIdCotizacion());

            ps.executeUpdate();
            insertar = true;
            System.out.println("Factura registrada exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al insertar la Factura: " + e.getMessage());
        }
        return insertar;
    }

    public boolean actualizarFactura(FacturasCabeceras miFactura) {
        boolean actualizar = false;
        Connection conn = conect.conn();

        try {
            String querySql = "UPDATE facturas_cabeceras SET total = ? "
                    + " WHERE id_factura = ?";

            PreparedStatement ps = conn.prepareStatement(querySql);

            ps.setFloat(1, miFactura.getTotal());
            ps.setInt(2, miFactura.getIdFactura());

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas > 0) {
                actualizar = true;
                System.out.println("Factura actualizada correctamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar la Factura: " + e.getMessage());
        }
        return actualizar;
    }

    public boolean eliminarFactura(int idFactura) {
        boolean eliminar = false;
        Connection conn = conect.conn();

        try {
            String querySql = "DELETE FROM facturas_cabeceras WHERE id_factura = ?";
            PreparedStatement ps = conn.prepareStatement(querySql);

            ps.setInt(1, idFactura);

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas > 0) {
                eliminar = true;
            } else {
                System.out.println("No se encontró el ID de la Factura.");
            }
        } catch (SQLException e) {
            System.out.println("No se pudo eliminar la Factura: " + e.getMessage());
        }
        return eliminar;
    }
}