package Controlador;
import Modelo.Productos;
import java.sql.*;


public class ProductosDAO {
    
    private Conexion conect = new Conexion();
    
    public Productos consultarProductos(String descripcion){
    
    Productos miProducto = null;
    
    Connection conn = conect.conn();
        
        try {
            String querySql = "SELECT id_producto, descripcion, precio, id_catalogo "
                    + "FROM productos WHERE descripcion = ?";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setString(1, descripcion);
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                
                miProducto = new Productos();
                miProducto.setIdProducto(rs.getInt("id_producto"));
                miProducto.setDescripcion(rs.getString("descripcion"));
                miProducto.setPrecio(rs.getFloat("precio"));
                miProducto.setIdCatalogo(rs.getInt("id_catalogo"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return miProducto;
    }
    
    public boolean insertarProductos(Productos miProducto){
        
        boolean insertar = false;
        
        Connection conn = conect.conn();
        
        try {
            String querySql = "INSERT INTO productos (descripcion, precio, id_catalogo) "
                    + "VALUES (?,?,?)";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setString(1, miProducto.getDescripcion());
            ps.setFloat(2, miProducto.getPrecio());
            ps.setInt(3, miProducto.getIdCatalogo());
            
            ps.executeUpdate();
            insertar = true;
            System.out.println("Producto registrado exitosamente");
        } catch (SQLException e) {
            System.out.println("Error al insertar Producto: " + e.getMessage());
        }
            return insertar;
    }
    
    public boolean actualizarProducto(Productos miProducto){
    
        boolean actualizar = false; 
        
        Connection conn = conect.conn();
        
        try {
            
            String querySql = "UPDATE productos SET descripcion = ?, precio = ? WHERE id_producto = ?";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setString(1, miProducto.getDescripcion());
            ps.setFloat(2, miProducto.getPrecio());
            ps.setInt(3, miProducto.getIdCatalogo());
            
            int filasAfectadas = ps.executeUpdate();
            
            if (filasAfectadas > 0) {
                
                actualizar = true;
                System.out.println("Producto actualizado correctamente");
                
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar Producto: " + e.getMessage());
            
        }
        return actualizar;
    }
    
    public boolean inactivarProducto(int id){
    
        boolean inactivar = false;
        String querySql = "UPDATE productos SET estado = FALSE WHERE id_producto = ? ";
        
        Connection conn = conect.conn();
        
        try {
          
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, id);
            if (ps.executeUpdate() > 0) {
                inactivar = true;
                
            }
        } catch (SQLException e) {
            System.out.println("Error al inactivar el Producto");
        }
        return inactivar; 
    }
    
    public boolean activarProducto(int id){
    
        boolean activar = false;
        String querySql = "UPDATE productos SET estado = TRUE WHERE id_producto = ? ";
        
        Connection conn = conect.conn();
        
        try {
          
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, id);
            if (ps.executeUpdate() > 0) {
                activar = true;
                
            }
        } catch (SQLException e) {
            System.out.println("Error al activar el Producto");
        }
        return activar; 
    }
    
    public boolean eliminarProducto(int id){
    
        boolean eliminar = false; 
        
        Connection conn = conect.conn();
        
        try {
            String querySql = "DELETE FROM productos WHERE id_producto = ? ";
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            
            if (filasAfectadas > 0) {
                eliminar = true;
                
            }else{
                System.out.println("No se encontro el ID del Producto");
            }
        } catch (SQLException e) {
            System.out.println("No se pudo eliminar el Producto: " + e.getMessage());
        }
        return eliminar;
    }
    
}
