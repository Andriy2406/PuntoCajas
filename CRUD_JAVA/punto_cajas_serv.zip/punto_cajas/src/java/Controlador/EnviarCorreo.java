package Controlador;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.Properties;

public class EnviarCorreo {

    private final String correoRemitente = "punto.cajas6@gmail.com";
    private final String claveAplicacion = "gvsq emmd ccar nuda";

    public boolean enviarCodigo(String correoDestino, String codigo) {
        Properties propiedades = new Properties();
        propiedades.put("mail.smtp.host", "smtp.gmail.com");
        propiedades.put("mail.smtp.port", "587");
        propiedades.put("mail.smtp.auth", "true");
        propiedades.put("mail.smtp.starttls.enable", "true");
        propiedades.put("mail.smtp.starttls.required", "true");
        propiedades.put("mail.smtp.ssl.protocols", "TLSv1.2");
        propiedades.put("mail.smtp.ssl.trust", "smtp.gmail.com");

        Session session = Session.getInstance(
                propiedades,
                new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(correoRemitente, claveAplicacion);
                    }
                }
        );

        try {
            Message mensaje = new MimeMessage(session);
            mensaje.setFrom(new InternetAddress(correoRemitente));
            mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(correoDestino));
            mensaje.setSubject("Punto Cajas - Código de recuperación");
            mensaje.setText(
                    "Hola,\n\n"
                    + "Tu código de recuperación de Punto Cajas es: " + codigo + "\n\n"
                    + "Este código tiene una validez de 10 minutos.\n\n"
                    + "Si no solicitaste recuperar tu clave, ignora este mensaje."
            );

            Transport.send(mensaje);
            System.out.println("Correo enviado correctamente a: " + correoDestino);
            return true;
        } catch (Exception e) {
            System.out.println("Error al enviar correo: " + e.getMessage());
            return false;
        }
    }
}