/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import Modelo.PedidosDetalles;
import java.sql.*;

/**
 *
 * @author Nelson
 */
public class PedidosDetallesDAO {
    
    private Conexion conect = new Conexion();
    
    public PedidosDetalles consultarPedidosDetalles (int idPedidoDetalle){
    
        PedidosDetalles miPedidosDetalles = null;
        
        Connection conn = conect.conn();
        
        try {
            
            String querySql = "SELECT id_pedido_detalle, cantidad, subtotal, id_pedido, id_cotizacion FROM pedidos_detalles WHERE id_pedido_detalle = ?";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setInt(1, idPedidoDetalle);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
            
                miPedidosDetalles = new PedidosDetalles();
                miPedidosDetalles.setIdPedidoDetalle(rs.getInt("id_pedido_detalle"));
                miPedidosDetalles.setCantidad(rs.getInt("cantidad"));
                miPedidosDetalles.setSubtotal(rs.getFloat("subtotal"));
                miPedidosDetalles.setIdPedido(rs.getInt("id_pedido"));
                miPedidosDetalles.setIdCotizacion(rs.getInt("id_cotizacion"));
            }
            
        } catch (SQLException e) {
            System.out.println("Error al consultar los datos " + e.getMessage());
        }
        return miPedidosDetalles;
    }
    
    public boolean insertarPedidosDetalles (PedidosDetalles miPedidosDetalles){
    
        boolean insertar = false;
        
        Connection conn = conect.conn();
        
        try {
            
            String querySql = "INSERT INTO pedidos_detalles (cantidad, subtotal, id_pedido, id_cotizacion) VALUES (?, ?, ?, ?)";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setInt(1, miPedidosDetalles.getCantidad());
            ps.setFloat(2, miPedidosDetalles.getSubtotal());
            ps.setInt(3, miPedidosDetalles.getIdPedido());
            ps.setInt(4, miPedidosDetalles.getIdCotizacion());
            
            ps.executeUpdate();
            insertar = true;
            System.out.println("Datos ingresados correctamente");
            
        } catch (SQLException e) {
                System.out.println("Error al ingresar datos " + e.getMessage());
        }
        return insertar;
    }
    
    public boolean actualizarPedidosDetalles(PedidosDetalles miPedidosDetalles){
    
        boolean actualizar = false;
        
        Connection conn = conect.conn();
        
        try {
            String querySql = "UPDATE pedidos_detalles SET cantidad = ?, subtotal = ? WHERE id_pedido_detalle = ?";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, miPedidosDetalles.getCantidad());
            ps.setFloat(2, miPedidosDetalles.getSubtotal());
            ps.setInt(3, miPedidosDetalles.getIdPedidoDetalle());
            
            if(ps.executeUpdate() > 0){
            
                actualizar = true;
                System.out.println("Registro actualizado correctamente");
            }
        } catch (SQLException e) {
            System.out.println("Error al acutalizar el pedido detalle " + e.getMessage());
        }
        return actualizar;
    
    }
    
    public boolean eliminarPedidosDetalles (int idPedidoDetalle){
        boolean eliminar = false;
        Connection conn = conect.conn();
        
        try {
            String querySql = "DELETE FROM pedidos_detalles WHERE id_pedido_detalle = ?";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setInt(1, idPedidoDetalle);
            
            int filaEliminada = ps.executeUpdate();
            
            if (filaEliminada > 0){
                eliminar = true;
            }else{
                System.out.println("Error al encontrar el ID");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el detalle permiso");
        }
        return eliminar;
    }
}
