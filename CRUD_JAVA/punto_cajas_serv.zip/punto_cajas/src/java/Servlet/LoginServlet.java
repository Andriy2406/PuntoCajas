package Servlet;

import Controlador.UsuarioDAO;
import Modelo.Usuarios;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(
        name = "LoginServlet",
        urlPatterns = {"/LoginServlet"}
)
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String correo = request.getParameter("correo");
        String clave = request.getParameter("clave");


        UsuarioDAO dao = new UsuarioDAO();


        Usuarios usuarioLogueado =
                dao.validarLogin(correo, clave);


        if (usuarioLogueado != null) {

            HttpSession session =
                    request.getSession();

            session.setAttribute(
                    "usuarioActivo",
                    usuarioLogueado
            );

            response.sendRedirect(
                    request.getContextPath()
                    + "/InicioServlet"
            );


        } else {

            request.setAttribute(
                    "error",
                    "El correo o la contraseña son incorrectos."
            );

            request.getRequestDispatcher(
                    "/Vista/Login.jsp"
            ).forward(request, response);

        }

    }

}