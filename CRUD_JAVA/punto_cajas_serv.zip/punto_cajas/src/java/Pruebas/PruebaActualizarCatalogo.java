package Pruebas;
import Modelo.Catalogos;
import Controlador.CatalogosDAO;
import java.util.Scanner;


public class PruebaActualizarCatalogo {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner (System.in);
        Catalogos miCatalogo = new Catalogos();
        CatalogosDAO dao = new CatalogosDAO();
    
        System.out.println("Ingrese el ID del Catalogo que desea actualizar: ");
        int actualizar = sc.nextInt();
        sc.nextLine();
        miCatalogo.setIdCatalogo(actualizar);
        
        System.out.println("Ingrese el nuevo Stock Actual: ");
        miCatalogo.setStockActual(sc.nextLine());
        
        System.out.println("Ingrese la nueva URL: ");
        miCatalogo.setUrl(sc.nextLine());
        
        boolean resultado = dao.actualizarCatalogo(miCatalogo);
        
        if (resultado) {
            System.out.println("El Catalogo se actualizo correctamente");
        }else{
            System.out.println("El Catalogo no se encontro");
        }
                         
                
    }
    
}
