package Pruebas;
import Controlador.ProductosDAO;
import java.util.Scanner;

public class PruebaEliminarProducto {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        ProductosDAO dao = new ProductosDAO();
        
        try {
            System.out.println("Ingrese el ID del Producto a eliminar: ");
            int id = sc.nextInt();
            
            if (dao.eliminarProducto(id)) {
                System.out.println("Se elimino con exito");
            }
        } catch (Exception e) {
            System.out.println("Error al encontrar el Producto");
        }
    }
    
}
