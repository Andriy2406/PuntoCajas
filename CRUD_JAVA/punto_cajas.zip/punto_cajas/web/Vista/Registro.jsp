<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Crear cuenta | Punto Cajas</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  
  <%-- Ruta absoluta para el CSS --%>
  <link href="${pageContext.request.contextPath}/Vista/CSS/styles.css" rel="stylesheet">
</head>
<body>

  <nav class="navbar navbar-punto py-3">
    <div class="container">
      <a class="navbar-brand" href="${pageContext.request.contextPath}/Vista/index.jsp">
        <svg class="logo-caja" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
          <path d="M3 7l9-4 9 4-9 4-9-4z"/>
          <path d="M3 7v10l9 4 9-4V7"/>
          <path d="M12 11v10"/>
        </svg>
        Punto Cajas
      </a>
    </div>
  </nav>

  <main class="d-flex align-items-center">
    <div class="container">

      <div class="contenedor-formulario formulario-ancho">
        <h1>Crear cuenta</h1>
        <p class="subtitulo">Regístrate para cotizar y comprar tus cajas.</p>

        <%-- Bloque para mensajes de error o éxito desde el Servlet --%>
        <% 
           String mensaje = (String) request.getAttribute("mensaje");
           if (mensaje != null) { 
        %>
            <div class="alert alert-info text-center" role="alert">
                <%= mensaje %>
            </div>
        <% } %>

        <%-- Action apuntando al Servlet con método POST --%>
        <form novalidate action="${pageContext.request.contextPath}/UsuarioServlet" method="POST">
          
          <%-- Campo oculto para que el Servlet sepa que es un registro --%>
          <input type="hidden" name="accion" value="registrar">

          <!-- Datos personales -->
          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="nombre" class="form-label">Nombre</label>
              <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Tu nombre" required>
            </div>
            <div class="col-md-6 mb-3">
              <label for="apellido" class="form-label">Apellido</label>
              <input type="text" class="form-control" id="apellido" name="apellido" placeholder="Tu apellido" required>
            </div>
          </div>

          <!-- Documento de identidad -->
          <div class="row">
            <div class="col-md-5 mb-3">
              <label for="tipoDocumento" class="form-label">Tipo de documento</label>
              <select class="form-select" id="tipoDocumento" name="id_documento" required>
                <option value="" selected disabled>Selecciona...</option>
                <option value="CC">Cédula de ciudadanía</option>
                <option value="CE">Cédula de extranjería</option>
                <option value="TI">Tarjeta de identidad</option>
                <option value="PA">Pasaporte</option>
              </select>
            </div>
            <div class="col-md-7 mb-3">
              <label for="identificacion" class="form-label">Número de documento</label>
              <input type="text" class="form-control" id="identificacion" name="identificacion_usuario" placeholder="Ej: 1020304050" required>
            </div>
          </div>

          <!-- Contacto -->
          <div class="mb-3">
            <label for="correo" class="form-label">Correo electrónico</label>
            <input type="email" class="form-control" id="correo" name="correo" placeholder="nombre@correo.com" required>
          </div>

          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="telefono" class="form-label">Teléfono</label>
              <input type="tel" class="form-control" id="telefono" name="telefono" placeholder="Ej: 3001234567">
            </div>
            <div class="col-md-6 mb-3">
              <label for="fechaNacimiento" class="form-label">Fecha de nacimiento</label>
              <input type="date" class="form-control" id="fechaNacimiento" name="fecha_de_nacimiento">
            </div>
          </div>

          <div class="mb-3">
            <label for="direccion" class="form-label">Dirección</label>
            <input type="text" class="form-control" id="direccion" name="direccion" placeholder="Ej: Calle 10 # 20-30">
          </div>

          <!-- Contraseña -->
          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="clave" class="form-label">Contraseña</label>
              <input type="password" class="form-control" id="clave" name="clave" placeholder="Mínimo 6 caracteres" minlength="6" required>
            </div>
            <div class="col-md-6 mb-3">
              <label for="confirmarClave" class="form-label">Confirmar contraseña</label>
              <input type="password" class="form-control" id="confirmarClave" placeholder="Repite tu contraseña" minlength="6" required>
            </div>
          </div>

          <!-- Autorización de datos -->
          <div class="form-check mb-4">
            <input class="form-check-input" type="checkbox" id="autorizacionDatos" name="autorizaciondatos" required>
            <label class="form-check-label" for="autorizacionDatos">
              Autorizo el tratamiento de mis datos personales conforme a la política de privacidad.
            </label>
          </div>

          <button type="submit" class="btn btn-punto-primario w-100">Crear cuenta</button>
        </form>

        <p class="text-center mt-4 mb-0">
          ¿Ya tienes cuenta?
          <a href="${pageContext.request.contextPath}/Vista/Login.jsp">Inicia sesión aquí</a>
        </p>
      </div>

    </div>
  </main>

  <footer class="footer-punto">
    <div class="container text-center">
      <span>&copy; 2026 Punto Cajas. Todos los derechos reservados.</span>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>