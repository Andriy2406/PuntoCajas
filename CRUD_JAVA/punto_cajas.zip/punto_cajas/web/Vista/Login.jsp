<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Iniciar sesión | Punto Cajas</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  
  <%-- Ruta absoluta para que no se pierda el CSS al hacer forward desde el Servlet --%>
  <link href="${pageContext.request.contextPath}/Vista/CSS/styles.css" rel="stylesheet">
</head>
<body>

  <nav class="navbar navbar-punto py-3">
    <div class="container">
      <%-- Ruta absoluta para el logo/inicio --%>
      <a class="navbar-brand" href="${pageContext.request.contextPath}/Vista/index.html">
        <svg class="logo-caja" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="24" height="24">
          <path d="M3 7l9-4 9 4-9 4-9-4z"/>
          <path d="M3 7v10l9 4 9-4V7"/>
          <path d="M12 11v10"/>
        </svg>
        Punto Cajas
      </a>
    </div>
  </nav>

  <main class="d-flex align-items-center">
    <div class="container">

      <div class="contenedor-formulario">
        <h1>Iniciar sesión</h1>
        <p class="subtitulo">Ingresa con tu correo y contraseña registrados.</p>

        <%-- Bloque JSP para mostrar mensajes de error desde el Servlet --%>
        <% 
           String mensaje = (String) request.getAttribute("mensaje");
           if (mensaje != null) { 
        %>
            <div class="alert alert-danger text-center" role="alert">
                <%= mensaje %>
            </div>
        <% } %>

        <%-- Action actualizado apuntando al Servlet --%>
        <form novalidate action="${pageContext.request.contextPath}/inicio" method="POST">
          <div class="mb-3">
            <label for="correo" class="form-label">Correo electrónico</label>
            <input
              type="email"
              class="form-control"
              id="correo"
              name="correo"
              placeholder="nombre@correo.com"
              required>
          </div>

          <div class="mb-3">
            <label for="clave" class="form-label">Contraseña</label>
            <input
              type="password"
              class="form-control"
              id="clave"
              name="clave"
              placeholder="Tu contraseña"
              minlength="6"
              required>
          </div>

          <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="recordar">
              <label class="form-check-label" for="recordar">Recordarme</label>
            </div>
            <%-- Ruta absoluta para recuperar contraseña --%>
            <a href="${pageContext.request.contextPath}/Vista/recuperar.html" class="small">¿Olvidaste tu contraseña?</a>
          </div>

          <button type="submit" class="btn btn-punto-primario w-100">Iniciar sesión</button>
        </form>

        <p class="text-center mt-4 mb-0">
          ¿Aún no tienes cuenta?
          <%-- Ruta absoluta para el registro --%>
          <a href="${pageContext.request.contextPath}/Vista/registro.html">Regístrate aquí</a>
        </p>
      </div>

    </div>
  </main>

  <footer class="footer-punto">
    <div class="container text-center">
      <span>&copy; 2026 Punto Cajas. Todos los derechos reservados.</span>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>