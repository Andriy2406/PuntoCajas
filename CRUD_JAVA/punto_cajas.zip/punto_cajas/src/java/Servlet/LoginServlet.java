package Servlet;

import Controlador.UsuarioDAO;
import Modelo.Usuarios;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "LoginServlet", urlPatterns = {"/inicio"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String usuario = request.getParameter("correo"); 
        String password = request.getParameter("clave"); 

        // Validación de campos vacíos
        if (usuario == null || usuario.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            request.setAttribute("mensaje", "Por favor complete todos los campos");
            request.getRequestDispatcher("/Vista/Login.jsp").forward(request, response);
            return; 
        }

        UsuarioDAO midao = new UsuarioDAO();
        Usuarios usuarioBD = midao.consultarUsuario(usuario);

        // Si el usuario no existe
        if (usuarioBD == null || usuarioBD.getCorreo() == null) {
            request.setAttribute("mensaje", "El documento o usuario no existe");
            request.getRequestDispatcher("/Vista/Login.jsp").forward(request, response);

        // Si la clave es incorrecta
        } else if (!password.equals(usuarioBD.getClave())) {
            request.setAttribute("mensaje", "Clave incorrecta");
            request.getRequestDispatcher("/Vista/Login.jsp").forward(request, response);

        // Ingreso exitoso
        } else {
            HttpSession sesion = request.getSession();
            sesion.setAttribute("nombreUsuario", usuarioBD.getNombre());
            sesion.setAttribute("perfil", usuarioBD.getIdRol());
            
            // Redirección al index
            response.sendRedirect(request.getContextPath() + "/Vista/index.html");
        }
    }
}