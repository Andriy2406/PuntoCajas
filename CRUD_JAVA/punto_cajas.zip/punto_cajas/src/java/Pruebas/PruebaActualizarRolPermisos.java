/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Pruebas;

import Controlador.RolPermisosDAO;
import Modelo.RolPermisos;
import java.util.Scanner;

/**
 *
 * @author Aprendiz
 */
public class PruebaActualizarRolPermisos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        RolPermisos miRolPermisos = new RolPermisos();
        RolPermisosDAO miRolPermisosDAO = new RolPermisosDAO();
        
        System.out.println("Ingrese el ID del rol: ");
        int idRol = sc.nextInt();
        sc.nextLine();
        
        miRolPermisos.setIdRol(idRol);
        
        System.out.println("Ingrese el nuevo ID rol");
        miRolPermisos.setIdRol(sc.nextInt());
        
        System.out.println("Ingrese el nuevo ID permiso");
        miRolPermisos.setIdPermiso(sc.nextInt());
        
        boolean resultado = miRolPermisosDAO.actualizarRolPermisos(miRolPermisos);
        if(resultado){
            System.out.println("Se actualizo correctamente");
        }else{
            System.out.println("No se pudo actualizar");
        }
    }
    
}
