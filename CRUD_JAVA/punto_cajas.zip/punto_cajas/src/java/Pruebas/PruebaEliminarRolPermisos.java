/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Pruebas;
import java.util.Scanner;
import Controlador.RolPermisosDAO;

/**
 *
 * @author Aprendiz
 */
public class PruebaEliminarRolPermisos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        RolPermisosDAO miRolPermisosDAO = new RolPermisosDAO();
        
        try {
            System.out.println("Ingrese el ID que desea eliminar: ");
            int idRol = sc.nextInt();
            
            if(miRolPermisosDAO.eliminarRolPermisos(idRol)){
                System.err.println("Se elimino con exito");
            }
        } catch (Exception e) {
            System.out.println("Error al borrar el registro " +e.getMessage());
        }
    }
    
}
