package Controlador;
import Modelo.Productos;
import java.sql.*;


public class ProductosDAO {
    
    private Conexion conect = new Conexion();
    
    public Productos consultarProductos(String descripcion){
    
    Productos miProducto = null;
    
    Connection conn = conect.conn();
        
        try {
            String querySql = "SELECT id_producto, descripcion, precio, id_catalogo "
                    + "FROM productos WHERE descripcion = ?";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setString(1, descripcion);
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                
                miProducto = new Productos();
                miProducto.setIdProducto(rs.getInt("id_producto"));
                miProducto.setDescripcion(rs.getString("descripcion"));
                miProducto.setPrecio(rs.getFloat("precio"));
                miProducto.setIdCatalogo(rs.getInt("id_catalogo"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return miProducto;
    }
    
    public boolean insertarProductos(Productos miProducto){
        
        boolean insertar = false;
        
        Connection conn = conect.conn();
        
        try {
            String querySql = "INSERT INTO productos (descripcion, precio, id_catalogo) "
                    + "VALUES (?,?,?)";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setString(1, miProducto.getDescripcion());
            ps.setFloat(2, miProducto.getPrecio());
            ps.setInt(3, miProducto.getIdCatalogo());
            
            ps.executeUpdate();
            insertar = true;
            System.out.println("Producto registrado exitosamente");
        } catch (Exception e) {
            System.out.println("Error al insertar Producto: " + e.getMessage());
        }
            return insertar;
    }
    
}
