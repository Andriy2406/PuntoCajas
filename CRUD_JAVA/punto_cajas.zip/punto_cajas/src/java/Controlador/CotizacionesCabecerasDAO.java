package Controlador;
import Modelo.CotizacionesCabeceras;
import java.sql.*;
import java.time.LocalDate;

public class CotizacionesCabecerasDAO {
    
    private Conexion conect = new Conexion();
    
    public CotizacionesCabeceras consultarCotizacionC(LocalDate fecha){
    
        CotizacionesCabeceras miCotizacionC = null;
        
        Connection conn = conect.conn();
        
        try {
            String querySql = "SELECT id_cotizacion, fecha, valor_unitario, iva, subtotal, "
                   + " total, id_usuario, id_doc_con FROM cotizaciones_cabeceras WHERE fecha = ?";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            ps.setDate(1, java.sql.Date.valueOf(fecha));
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                
                miCotizacionC = new CotizacionesCabeceras();
                
                miCotizacionC.setIdCotizacion(rs.getInt("id_cotizacion"));
                java.sql.Date fechaSql = rs.getDate("fecha");
                if (fechaSql != null) {
                    miCotizacionC.setFecha(fechaSql.toLocalDate());
                }
                miCotizacionC.setValorUnitario(rs.getFloat("valor_unitario"));
                miCotizacionC.setIva(rs.getFloat("iva"));
                miCotizacionC.setSubtotal(rs.getFloat("subtotal"));
                miCotizacionC.setTotal(rs.getFloat("total"));
                miCotizacionC.setIdUsuario(rs.getInt("id_usuario"));
                miCotizacionC.setIdDocCon(rs.getInt("id_doc_con"));
                
            }
        } catch (SQLException e) {
            
            System.out.println(e.getMessage());
        }
        return miCotizacionC;
    }
    
    
    public boolean insertarCotizacionC(CotizacionesCabeceras miCotizacionC){
    
    boolean insertar = false;
    
    Connection conn = conect.conn();
    
        try {
            String querySql = "INSERT INTO cotizaciones_cabeceras (fecha, valor_unitario, iva, "
                    + " subtotal, total, id_usuario, id_doc_con) VALUES (?,?,?,?,?,?,?)";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            
            if (miCotizacionC.getFecha() != null) {
                ps.setDate(1, java.sql.Date.valueOf(miCotizacionC.getFecha()));
            } else{
                ps.setNull(1, java.sql.Types.DATE);
            }
            
            ps.setFloat(2, miCotizacionC.getValorUnitario());
            ps.setFloat(3, miCotizacionC.getIva());
            ps.setFloat(4, miCotizacionC.getSubtotal());
            ps.setFloat(5, miCotizacionC.getTotal());
            ps.setInt(6, miCotizacionC.getIdUsuario());
            ps.setInt(7, miCotizacionC.getIdDocCon());
            
            ps.executeUpdate();
            insertar = true;
            System.out.println("Cotizacion Cabecera registrada exitosamente");
        } catch (Exception e) {
            System.out.println("Error al insertar la Cotizacion Cabecera: " + e.getMessage());
        }
            return insertar;
    }
    
    
}
